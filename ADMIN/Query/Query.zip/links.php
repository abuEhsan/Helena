<li class="nav-item">
<a class="nav-link collapsed" href="Links.php">
  <i class="bi bi-link-45deg"></i>
  <span><?php echo " إدارة الروابط ";?></span>
</a>
</li><!-- End links Page Nav -->