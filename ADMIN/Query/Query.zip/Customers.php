<li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#Cust-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-people-fill"></i><span> <?php echo "الموارد البشرية  ";?></span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="Cust-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="Manage-Customers.php">
              <i class="bi bi-circle"></i><span><?php echo "إدارة المشتركين";?></span>
            </a>
          </li>
        </ul>
</li><!-- End Products Nav -->