<li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#service-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-plus-circle-fill"></i><span> <?php echo "الخدمات ";?></span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="service-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="services.php">
              <i class="bi bi-circle"></i><span><?php echo "إدارة الخدمات";?></span>
            </a>
          </li>
        </ul>
</li><!-- End Products Nav -->