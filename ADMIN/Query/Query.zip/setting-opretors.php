<li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#Page-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-gear-fill"></i><span> <?php echo " اعدادات العمليات";?></span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="Page-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
           <li>
            <a href="Colors.php">
              <i class="bi bi-circle"></i><span><?php echo " اللوان المنتجات ";?></span>
            </a>
          </li>
          <li>
            <a href="Sizes.php">
              <i class="bi bi-circle"></i><span><?php echo " مقاسات المنتجات ";?></span>
            </a>
          </li>
          <li>
            <a href="Currnces.php">
              <i class="bi bi-circle"></i><span><?php echo " العملات ";?></span>
            </a>
          </li>
          <li>
            <a href="Payments-Away.php">
              <i class="bi bi-circle"></i><span><?php echo "طرق الدفع";?></span>
            </a>
          </li>
          <li>
            <a href="Shipping-Cost.php">
              <i class="bi bi-circle"></i><span><?php echo "الحسابات البنكية ";?></span>
            </a>
          </li>
        </ul>
</li><!-- End Setting Nav -->