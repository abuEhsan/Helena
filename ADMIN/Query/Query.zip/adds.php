<li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#Adds-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-megaphone-fill"></i><span>  <?php echo "العروض";?>  </span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="Adds-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="Adds.php">
              <i class="bi bi-circle"></i><span>  <?php echo "إدارة العروض";?> </span>
            </a>
          </li>
        </ul>
</li><!-- End Add Nav -->
