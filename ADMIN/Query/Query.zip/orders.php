

    <li class="nav-item">
       <a class="nav-link collapsed" data-bs-target="#Pleading-nav" data-bs-toggle="collapse" href="#">
         <i class="bi bi-cart4"></i><span>  <?php echo " الطلبات";?>  </span><i class="bi bi-chevron-down ms-auto"></i>
       </a>
       <ul id="Pleading-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
        <li>
           <a href="Manage-Pleading-Adds.php">
             <i class="bi bi-circle"></i><span>  <?php echo "إدارة الطلبات";?> </span>
           </a>
        </li>
         
       </ul>
    </li><!-- End Orders Nav --> 
