 
<li class="nav-item">
      <a class="nav-link collapsed" href="Pro-Conditions.php">
        <i class="bi bi-list"></i>
        <span><?php echo " إدارة البنود ";?></span>
      </a>
</li><!-- End Conditions Page Nav -->