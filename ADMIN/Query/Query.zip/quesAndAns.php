<li class="nav-item">
    <a class="nav-link collapsed" href="Question-And-Answer.php">
        <i class="bi bi-question-circle"></i>
        <span><?php echo "إدارة الاسئلة الشائعة ";?> </span>
    </a>
</li><!-- End F.A.Q Page Nav -->