<li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#Page-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-sliders"></i><span> <?php echo " اعدادات القوائم";?></span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="Page-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="Manage-Slider-Main.php">
              <i class="bi bi-circle"></i><span><?php echo " العارض الرئيسي";?></span>
            </a>
          </li>
          <li>
            <a href="Manage-Slider-Service.php">
              <i class="bi bi-circle"></i><span><?php echo " عارض الخدمات ";?></span>
            </a>
          </li>
        </ul>
</li><!-- End Setting Nav -->