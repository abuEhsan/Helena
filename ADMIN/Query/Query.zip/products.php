<li class="nav-item">
        <a class="nav-link collapsed" data-bs-target="#Product-nav" data-bs-toggle="collapse" href="#">
          <i class="bi bi-palette2"></i><span> <?php echo "الاصناف/المنتجات ";?></span><i class="bi bi-chevron-down ms-auto"></i>
        </a>
        <ul id="Product-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
          <li>
            <a href="Products.php">
              <i class="bi bi-circle"></i><span><?php echo "إدارة المنتجات";?></span>
            </a>
          </li>
         <li>
            <a href="Category.php">
              <i class="bi bi-circle"></i><span><?php echo "إدارة الأصناف";?></span>
            </a>
          </li>
        </ul>
</li><!-- End Products Nav -->