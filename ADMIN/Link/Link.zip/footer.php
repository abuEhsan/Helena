  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer" style="font-family: 'Cairo';">
    <div class="copyright" dir="rtl">
    متجر | <strong>   <span><?php echo htmlentities($CNAME);?></span></strong> 
    </div>
    <div class="credits">
<!--      <a href="<?php echo htmlentities($Domain);?>"><?php echo htmlentities($CNAME);?></a>-->
    </div>
  </footer><!-- End Footer -->
  