<?php
//
//ob_start();
//session_start();
//include("config.php");
//include("functions.php");
//include("CSRF_Protect.php");
//
//// Getting all language variables into array as global variable
//if(isset($_GET['languge'])){
//  $flag=1;
//  $_SESSTION['languge']=$_GET['languge'];  
//}else{
//    $_SESSTION['languge']=1; //defult languge
//}
//$i=1;
//$statement = $pdo->prepare("SELECT * FROM tbl_language WHERE languge='".$_SESSTION['languge']."'");
//$statement->execute();
//$result = $statement->fetchAll(PDO::FETCH_ASSOC);							
//foreach ($result as $row) {
//	define('LANG_VALUE_'.$i,$row['lang_value']);
//	$i++;
//}
//


?>