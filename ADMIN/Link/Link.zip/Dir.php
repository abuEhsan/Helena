<?php



//All Directory Of System


$DirassetsImage='assets/img/'; 
$DirUPLOADIN_Uploads_File='UPLOADING/Uploads-Files/';
$DirUPLOADIN_Uploads_File_Adds='UPLOADING/Uploads-Files-Adds/';
$DirUPLOADIN_Uploads_File_Category='UPLOADING/Uploads-Files-Category/';
$DirUPLOADIN_Uploads_File_Products='UPLOADING/Uploads-Files-Products/';
$DirUPLOADIN_Uploads_File_Services='UPLOADING/Uploads-Files-Services/';
$DirUPLOADIN_Uploads_File_Slider='UPLOADING/Uploads-Files-Slider/';
$DirUPLOADIN_Uploads_File_Images_Emploies_Admin='UPLOADING/Uploads-Images-File-Emploies-Admin/'; 

 