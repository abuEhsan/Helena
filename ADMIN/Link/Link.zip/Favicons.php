<?php

$FAVICONS=$DirassetsImage.$ICON;

define("FAVICONS",$FAVICONS);
define("FAVICONSAPP",$FAVICONS);

