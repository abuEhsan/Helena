<?php
session_start();
require_once('Links/Setting.php');
//if (! empty($_POST["p_id"])) {
//    $memberId = $_SESSION['customer']['cust_email'];;
//        $sql = "INSERT INTO tbl_whish_list (product_id, member_id) VALUES (?, ?)";
//        $paramType = 'ii';
//        $paramValue = array(
//            $_POST["p_id"],
//            $memberId
//        );
//        $whishlist_id = $dbh->insert($sql, $paramType, $paramValue);
//        echo $whishlist_id;
//    exit();
//}








if(isset($_POST['product_id'])) {  
   $addmemberid = $_SESSION['customer']['cust_id'];
    $addproductid = $_GET['product_id'];
    $sql="SELECT count(id) cnt FROM tblwhish_list WHERE member_id = '$addmemberid' AND product_id = '$addproductid'";
    $query = $dbh->prepare($sql);
    $query->execute();
    $results=$query->fetch();
    if($results['cnt'] == 1):
        $sql="DELETE FROM tblwhish_list WHERE member_id = '$addproductid' AND product_id = '$addmemberid'";
        $query = $dbh->prepare($sql);
        $query->execute();
        //from Database
        echo '0';
    else:
        $sql="INSERT INTO tblwhish_list SET product_id = '$addproductid', member_id = '$addmemberid'";
        $query = $dbh->prepare($sql);
        $query->execute();
        //from Database
        echo '1';
    endif;
}

?>